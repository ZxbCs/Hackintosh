[暗影精灵2 10.15.4正式版 oc引导](http://bbs.pcbeta.com/viewthread-1859136-1-1.html)

- i5 6300hq
- gtx960m（已屏蔽）
- 声卡，usb均已完成定制，缓冲帧已定制